#include "../include/game.h"
int main()
{
	Game g;
	g.initiateGame();
	return 0;
}

