#include<vector>
#include"conio.h"
#include <iostream>
#include<cstdlib>
#include<windows.h>
#include<stdio.h>
#include<stdlib.h>
//#include<conio.h>
#include<ctime>
#include<fstream>
using namespace std;
