#ifndef __GLOBAL__
#define __GLOBAL__
#include "macros.h"

#endif
